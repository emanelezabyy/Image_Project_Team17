import socket
import cv2
import pickle
import struct

HOST = "0.0.0.0"
PORT = 9999

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((HOST, PORT))
server.listen(1)

print("Waiting for Pi...")
conn, addr = server.accept()
print(f"Connected from {addr}")

data = b""
payload_size = struct.calcsize(">L")

while True:
    try:
        # Receive header (frame size)
        while len(data) < payload_size:
            packet = conn.recv(4096)
            if not packet:
                print("Connection closed")
                break
            data += packet

        if len(data) < payload_size:
            break

        packed_size = data[:payload_size]
        data = data[payload_size:]

        if len(packed_size) != 4:
            print("Invalid header size")
            continue

        msg_size = struct.unpack(">L", packed_size)[0]

        # Receive full frame
        while len(data) < msg_size:
            packet = conn.recv(4096)
            if not packet:
                break
            data += packet

        if len(data) < msg_size:
            break

        frame_data = data[:msg_size]
        data = data[msg_size:]

        # Decode frame
        frame = pickle.loads(frame_data)
        frame = cv2.imdecode(frame, cv2.IMREAD_COLOR)

        cv2.imshow("Goalkeeper System", frame)

        if cv2.waitKey(1) & 0xFF == 27:
            break

    except Exception as e:
        print("Error:", e)
        break

cv2.destroyAllWindows()
conn.close()
server.close()
